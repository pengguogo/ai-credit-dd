# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

from ..._httpx import httpx
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.sandboxes import registry_list_params, registry_create_params, registry_update_params
from ...types.sandboxes.registry_response import RegistryResponse
from ...types.sandboxes.registry_list_response import RegistryListResponse

__all__ = ["RegistriesResource", "AsyncRegistriesResource"]


class RegistriesResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> RegistriesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/langchain-ai/langsmith-python#accessing-raw-response-data-eg-headers
        """
        return RegistriesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> RegistriesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/langchain-ai/langsmith-python#with_streaming_response
        """
        return RegistriesResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        name: str,
        url: str,
        auth_type: Literal["DOCKER_CONFIG", "AWS_ROLE"] | Omit = omit,
        aws_role_arn: str | Omit = omit,
        password: str | Omit = omit,
        username: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RegistryResponse:
        """
        Create a sandbox registry for pulling private images.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/v2/sandboxes/registries",
            body=maybe_transform(
                {
                    "name": name,
                    "url": url,
                    "auth_type": auth_type,
                    "aws_role_arn": aws_role_arn,
                    "password": password,
                    "username": username,
                },
                registry_create_params.RegistryCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RegistryResponse,
        )

    def retrieve(
        self,
        name: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RegistryResponse:
        """
        Get a sandbox registry by name.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not name:
            raise ValueError(f"Expected a non-empty value for `name` but received {name!r}")
        return self._get(
            path_template("/api/v2/sandboxes/registries/{name}", name=name),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RegistryResponse,
        )

    def update(
        self,
        path_name: str,
        *,
        auth_type: Literal["DOCKER_CONFIG", "AWS_ROLE"] | Omit = omit,
        aws_role_arn: str | Omit = omit,
        body_name: str | Omit = omit,
        password: str | Omit = omit,
        url: str | Omit = omit,
        username: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RegistryResponse:
        """
        Update a sandbox registry's name and/or credentials.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_name:
            raise ValueError(f"Expected a non-empty value for `path_name` but received {path_name!r}")
        return self._patch(
            path_template("/api/v2/sandboxes/registries/{path_name}", path_name=path_name),
            body=maybe_transform(
                {
                    "auth_type": auth_type,
                    "aws_role_arn": aws_role_arn,
                    "body_name": body_name,
                    "password": password,
                    "url": url,
                    "username": username,
                },
                registry_update_params.RegistryUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RegistryResponse,
        )

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        name_contains: str | Omit = omit,
        offset: int | Omit = omit,
        page_size: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RegistryListResponse:
        """List sandbox registries for pulling private images.

        Page with page_size and
        cursor, replaying next_cursor until it is null. Results are ordered newest
        first, with stable ordering for equal creation times. Keep filters unchanged
        between pages. Requests without page_size or cursor retain the legacy default of
        50 results. Cursor requests default to 20 results, with a maximum of 100.

        Args:
          cursor: Opaque cursor from a prior response's next_cursor

          limit: Deprecated: use page_size. Maximum number of registries to return

          name_contains: Filter to registries whose name contains this substring

          offset: Deprecated: use cursor. Number of registries to skip

          page_size: Number of results per cursor page

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/api/v2/sandboxes/registries",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                        "name_contains": name_contains,
                        "offset": offset,
                        "page_size": page_size,
                    },
                    registry_list_params.RegistryListParams,
                ),
            ),
            cast_to=RegistryListResponse,
        )

    def delete(
        self,
        name: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a sandbox registry by name.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not name:
            raise ValueError(f"Expected a non-empty value for `name` but received {name!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template("/api/v2/sandboxes/registries/{name}", name=name),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncRegistriesResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncRegistriesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/langchain-ai/langsmith-python#accessing-raw-response-data-eg-headers
        """
        return AsyncRegistriesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncRegistriesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/langchain-ai/langsmith-python#with_streaming_response
        """
        return AsyncRegistriesResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        name: str,
        url: str,
        auth_type: Literal["DOCKER_CONFIG", "AWS_ROLE"] | Omit = omit,
        aws_role_arn: str | Omit = omit,
        password: str | Omit = omit,
        username: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RegistryResponse:
        """
        Create a sandbox registry for pulling private images.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/v2/sandboxes/registries",
            body=await async_maybe_transform(
                {
                    "name": name,
                    "url": url,
                    "auth_type": auth_type,
                    "aws_role_arn": aws_role_arn,
                    "password": password,
                    "username": username,
                },
                registry_create_params.RegistryCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RegistryResponse,
        )

    async def retrieve(
        self,
        name: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RegistryResponse:
        """
        Get a sandbox registry by name.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not name:
            raise ValueError(f"Expected a non-empty value for `name` but received {name!r}")
        return await self._get(
            path_template("/api/v2/sandboxes/registries/{name}", name=name),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RegistryResponse,
        )

    async def update(
        self,
        path_name: str,
        *,
        auth_type: Literal["DOCKER_CONFIG", "AWS_ROLE"] | Omit = omit,
        aws_role_arn: str | Omit = omit,
        body_name: str | Omit = omit,
        password: str | Omit = omit,
        url: str | Omit = omit,
        username: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RegistryResponse:
        """
        Update a sandbox registry's name and/or credentials.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_name:
            raise ValueError(f"Expected a non-empty value for `path_name` but received {path_name!r}")
        return await self._patch(
            path_template("/api/v2/sandboxes/registries/{path_name}", path_name=path_name),
            body=await async_maybe_transform(
                {
                    "auth_type": auth_type,
                    "aws_role_arn": aws_role_arn,
                    "body_name": body_name,
                    "password": password,
                    "url": url,
                    "username": username,
                },
                registry_update_params.RegistryUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RegistryResponse,
        )

    async def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        name_contains: str | Omit = omit,
        offset: int | Omit = omit,
        page_size: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RegistryListResponse:
        """List sandbox registries for pulling private images.

        Page with page_size and
        cursor, replaying next_cursor until it is null. Results are ordered newest
        first, with stable ordering for equal creation times. Keep filters unchanged
        between pages. Requests without page_size or cursor retain the legacy default of
        50 results. Cursor requests default to 20 results, with a maximum of 100.

        Args:
          cursor: Opaque cursor from a prior response's next_cursor

          limit: Deprecated: use page_size. Maximum number of registries to return

          name_contains: Filter to registries whose name contains this substring

          offset: Deprecated: use cursor. Number of registries to skip

          page_size: Number of results per cursor page

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/api/v2/sandboxes/registries",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                        "name_contains": name_contains,
                        "offset": offset,
                        "page_size": page_size,
                    },
                    registry_list_params.RegistryListParams,
                ),
            ),
            cast_to=RegistryListResponse,
        )

    async def delete(
        self,
        name: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a sandbox registry by name.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not name:
            raise ValueError(f"Expected a non-empty value for `name` but received {name!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template("/api/v2/sandboxes/registries/{name}", name=name),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class RegistriesResourceWithRawResponse:
    def __init__(self, registries: RegistriesResource) -> None:
        self._registries = registries

        self.create = to_raw_response_wrapper(
            registries.create,
        )
        self.retrieve = to_raw_response_wrapper(
            registries.retrieve,
        )
        self.update = to_raw_response_wrapper(
            registries.update,
        )
        self.list = to_raw_response_wrapper(
            registries.list,
        )
        self.delete = to_raw_response_wrapper(
            registries.delete,
        )


class AsyncRegistriesResourceWithRawResponse:
    def __init__(self, registries: AsyncRegistriesResource) -> None:
        self._registries = registries

        self.create = async_to_raw_response_wrapper(
            registries.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            registries.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            registries.update,
        )
        self.list = async_to_raw_response_wrapper(
            registries.list,
        )
        self.delete = async_to_raw_response_wrapper(
            registries.delete,
        )


class RegistriesResourceWithStreamingResponse:
    def __init__(self, registries: RegistriesResource) -> None:
        self._registries = registries

        self.create = to_streamed_response_wrapper(
            registries.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            registries.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            registries.update,
        )
        self.list = to_streamed_response_wrapper(
            registries.list,
        )
        self.delete = to_streamed_response_wrapper(
            registries.delete,
        )


class AsyncRegistriesResourceWithStreamingResponse:
    def __init__(self, registries: AsyncRegistriesResource) -> None:
        self._registries = registries

        self.create = async_to_streamed_response_wrapper(
            registries.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            registries.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            registries.update,
        )
        self.list = async_to_streamed_response_wrapper(
            registries.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            registries.delete,
        )
