# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["OnlineCodeEvaluator", "ManagedCodeEvaluatorSettings"]


class ManagedCodeEvaluatorSettings(BaseModel):
    is_enabled: Optional[bool] = None

    key_name: Optional[str] = None


class OnlineCodeEvaluator(BaseModel):
    advanced_features_enabled: Optional[bool] = None

    code: Optional[str] = None

    code_evaluator_input: Optional[
        Literal["thread", "all_messages", "human_ai_pairs", "first_human_last_ai", "trajectory"]
    ] = None
    """
    CodeEvaluatorInput is which thread data the evaluator receives. Null for run
    evaluators.
    """

    dependencies: Optional[str] = None

    evaluator_build_error: Optional[str] = None

    evaluator_build_status: Optional[Literal["ENQUEUED", "BUILDING", "READY", "FAILED"]] = None

    evaluator_id: Optional[str] = None

    language: Optional[str] = None
    """Default: "python" """

    managed_code_evaluator_key: Optional[Literal["voice_metrics"]] = None

    managed_code_evaluator_settings: Optional[Dict[str, ManagedCodeEvaluatorSettings]] = None

    require_attachments: Optional[bool] = None
    """
    RequireAttachments opts the evaluator into selecting/presigning run attachments
    (s3_urls) at evaluation time. Default false.
    """

    workspace_secrets_keys: Optional[List[str]] = None
    """
    WorkspaceSecretsKeys names the workspace secrets this evaluator may use. Each is
    sent as a header on requests to the hosts allowed for that secret; evaluator
    code never sees the value. Requires advanced_features_enabled, and each secret
    needs an allowed host with a header.
    """
