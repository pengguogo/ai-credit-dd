from __future__ import annotations

import inspect
from types import TracebackType
from typing import Any, List, Generic, Iterable, Awaitable, cast
from typing_extensions import Self, Callable, Iterator, AsyncIterator

from ._types import ParsedResponseSnapshot
from ._events import (
    ResponseStreamEvent,
    ResponseTextDoneEvent,
    ResponseCompletedEvent,
    ResponseTextDeltaEvent,
    ResponseFunctionCallArgumentsDeltaEvent,
)
from ...._types import Omit, omit
from ...._utils import is_given, consume_sync_iterator, consume_async_iterator
from ...._compat import PYDANTIC_V1, model_copy
from ...._models import build, construct_type_unchecked
from ...._streaming import Stream, AsyncStream
from ....types.responses import (
    ParsedResponse,
    ResponseStreamEvent as RawResponseStreamEvent,
    ResponseOutputItemDoneEvent,
    ResponseOutputItemAddedEvent,
)
from ..._parsing._responses import TextFormatT, parse_text, parse_response
from ....types.responses.tool_param import ToolParam
from ....types.responses.parsed_response import (
    ParsedContent,
    ParsedResponseOutputItem,
    ParsedResponseOutputMessage,
    ParsedResponseFunctionToolCall,
)
from ....types.responses.response_output_item import ResponseOutputItem


class ResponseStream(Generic[TextFormatT]):
    def __init__(
        self,
        *,
        raw_stream: Stream[RawResponseStreamEvent],
        text_format: type[TextFormatT] | Omit,
        input_tools: Iterable[ToolParam] | Omit,
        starting_after: int | None,
    ) -> None:
        self._raw_stream = raw_stream
        self._response = raw_stream.response
        self._iterator = self.__stream__()
        self._state = ResponseStreamState(text_format=text_format, input_tools=input_tools)
        self._starting_after = starting_after

    def __next__(self) -> ResponseStreamEvent[TextFormatT]:
        return self._iterator.__next__()

    def __iter__(self) -> Iterator[ResponseStreamEvent[TextFormatT]]:
        for item in self._iterator:
            yield item

    def __enter__(self) -> Self:
        return self

    def __stream__(self) -> Iterator[ResponseStreamEvent[TextFormatT]]:
        for sse_event in self._raw_stream:
            events_to_fire = self._state.handle_event(sse_event)
            for event in events_to_fire:
                if self._starting_after is None or event.sequence_number > self._starting_after:
                    yield event

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self.close()

    def close(self) -> None:
        """
        Close the response and release the connection.

        Automatically called if the response body is read to completion.
        """
        self._response.close()

    def get_final_response(self) -> ParsedResponse[TextFormatT]:
        """Waits until the stream has been read to completion and returns
        the accumulated `ParsedResponse` object.
        """
        self.until_done()
        response = self._state._completed_response
        if not response:
            raise RuntimeError("Didn't receive a `response.completed` event.")

        return response

    def until_done(self) -> Self:
        """Blocks until the stream has been consumed."""
        consume_sync_iterator(self)
        return self


class ResponseStreamManager(Generic[TextFormatT]):
    def __init__(
        self,
        api_request: Callable[[], Stream[RawResponseStreamEvent]],
        *,
        text_format: type[TextFormatT] | Omit,
        input_tools: Iterable[ToolParam] | Omit,
        starting_after: int | None,
    ) -> None:
        self.__stream: ResponseStream[TextFormatT] | None = None
        self.__api_request = api_request
        self.__text_format = text_format
        self.__input_tools = input_tools
        self.__starting_after = starting_after

    def __enter__(self) -> ResponseStream[TextFormatT]:
        raw_stream = self.__api_request()

        self.__stream = ResponseStream(
            raw_stream=raw_stream,
            text_format=self.__text_format,
            input_tools=self.__input_tools,
            starting_after=self.__starting_after,
        )

        return self.__stream

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        if self.__stream is not None:
            self.__stream.close()


class AsyncResponseStream(Generic[TextFormatT]):
    def __init__(
        self,
        *,
        raw_stream: AsyncStream[RawResponseStreamEvent],
        text_format: type[TextFormatT] | Omit,
        input_tools: Iterable[ToolParam] | Omit,
        starting_after: int | None,
    ) -> None:
        self._raw_stream = raw_stream
        self._response = raw_stream.response
        self._iterator = self.__stream__()
        self._state = ResponseStreamState(text_format=text_format, input_tools=input_tools)
        self._starting_after = starting_after

    async def __anext__(self) -> ResponseStreamEvent[TextFormatT]:
        return await self._iterator.__anext__()

    async def __aiter__(self) -> AsyncIterator[ResponseStreamEvent[TextFormatT]]:
        async for item in self._iterator:
            yield item

    async def __stream__(self) -> AsyncIterator[ResponseStreamEvent[TextFormatT]]:
        async for sse_event in self._raw_stream:
            events_to_fire = self._state.handle_event(sse_event)
            for event in events_to_fire:
                if self._starting_after is None or event.sequence_number > self._starting_after:
                    yield event

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.close()

    async def close(self) -> None:
        """
        Close the response and release the connection.

        Automatically called if the response body is read to completion.
        """
        await self._response.aclose()

    async def get_final_response(self) -> ParsedResponse[TextFormatT]:
        """Waits until the stream has been read to completion and returns
        the accumulated `ParsedResponse` object.
        """
        await self.until_done()
        response = self._state._completed_response
        if not response:
            raise RuntimeError("Didn't receive a `response.completed` event.")

        return response

    async def until_done(self) -> Self:
        """Blocks until the stream has been consumed."""
        await consume_async_iterator(self)
        return self


class AsyncResponseStreamManager(Generic[TextFormatT]):
    def __init__(
        self,
        api_request: Awaitable[AsyncStream[RawResponseStreamEvent]],
        *,
        text_format: type[TextFormatT] | Omit,
        input_tools: Iterable[ToolParam] | Omit,
        starting_after: int | None,
    ) -> None:
        self.__stream: AsyncResponseStream[TextFormatT] | None = None
        self.__api_request = api_request
        self.__text_format = text_format
        self.__input_tools = input_tools
        self.__starting_after = starting_after

    async def __aenter__(self) -> AsyncResponseStream[TextFormatT]:
        raw_stream = await self.__api_request

        self.__stream = AsyncResponseStream(
            raw_stream=raw_stream,
            text_format=self.__text_format,
            input_tools=self.__input_tools,
            starting_after=self.__starting_after,
        )

        return self.__stream

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        if self.__stream is not None:
            await self.__stream.close()


def _output_identity(
    item: ResponseOutputItem | ParsedResponseOutputItem[object],
) -> tuple[str, str | None, str | None]:
    call_id = getattr(item, "call_id", None)
    if item.type in ("function_call", "custom_tool_call", "shell_call", "shell_call_output"):
        return item.type, None, call_id
    return item.type, getattr(item, "id", None), call_id


def _compatible_output_id(
    previous: ResponseOutputItem | ParsedResponseOutputItem[object], replacement: ResponseOutputItem
) -> bool:
    previous_id = getattr(previous, "id", None)
    return previous_id == getattr(replacement, "id", None) or (
        previous_id is None and previous.type in ("function_call", "custom_tool_call")
    )


class ResponseStreamState(Generic[TextFormatT]):
    def __init__(
        self,
        *,
        input_tools: Iterable[ToolParam] | Omit,
        text_format: type[TextFormatT] | Omit,
    ) -> None:
        self.__current_snapshot: ParsedResponseSnapshot | None = None
        self._completed_response: ParsedResponse[TextFormatT] | None = None
        self._completed_output: dict[int, ResponseOutputItem] = {}
        self._completed_positions: dict[tuple[str, str | None, str | None], int] = {}
        self._output_items: dict[int, ParsedResponseOutputItem[object]] = {}
        self._input_tools = [tool for tool in input_tools] if is_given(input_tools) else []
        self._text_format = text_format
        self._rich_text_format: type | Omit = text_format if inspect.isclass(text_format) else omit

    def handle_event(self, event: RawResponseStreamEvent) -> List[ResponseStreamEvent[TextFormatT]]:
        if event.type == "response.output_item.added":
            event = construct_type_unchecked(
                type_=ResponseOutputItemAddedEvent,
                value={
                    **vars(event),
                    **cast("dict[str, Any]", {} if PYDANTIC_V1 else (getattr(event, "__pydantic_extra__", None) or {})),
                    "item": getattr(event, "item", None),
                    "output_index": event.output_index,
                },
            )
        elif event.type == "response.output_item.done":
            event = construct_type_unchecked(
                type_=ResponseOutputItemDoneEvent,
                value={
                    **vars(event),
                    **cast("dict[str, Any]", {} if PYDANTIC_V1 else (getattr(event, "__pydantic_extra__", None) or {})),
                    "item": event.item,
                    "output_index": event.output_index,
                },
            )
        self.__current_snapshot = self.accumulate_event(event)

        events: List[ResponseStreamEvent[TextFormatT]] = []

        if event.type == "response.output_item.added" and getattr(event, "item", None) is None:
            return events
        elif event.type == "response.output_text.delta":
            output = self._get_output_item(event.output_index)
            assert output.type == "message"

            content = output.content[event.content_index]
            assert content.type == "output_text"

            events.append(
                build(
                    ResponseTextDeltaEvent,
                    content_index=event.content_index,
                    delta=event.delta,
                    item_id=event.item_id,
                    output_index=event.output_index,
                    sequence_number=event.sequence_number,
                    logprobs=event.logprobs,
                    type="response.output_text.delta",
                    snapshot=content.text,
                )
            )
        elif event.type == "response.output_text.done":
            output = self._get_output_item(event.output_index)
            assert output.type == "message"

            content = output.content[event.content_index]
            assert content.type == "output_text"

            events.append(
                build(
                    cast("type[ResponseTextDoneEvent[TextFormatT]]", ResponseTextDoneEvent),
                    content_index=event.content_index,
                    item_id=event.item_id,
                    output_index=event.output_index,
                    sequence_number=event.sequence_number,
                    logprobs=event.logprobs,
                    type="response.output_text.done",
                    text=event.text,
                    parsed=parse_text(event.text, text_format=self._text_format, phase=output.phase),
                )
            )
        elif event.type == "response.function_call_arguments.delta":
            output = self._get_output_item(event.output_index)
            assert output.type == "function_call"

            events.append(
                build(
                    ResponseFunctionCallArgumentsDeltaEvent,
                    delta=event.delta,
                    item_id=event.item_id,
                    output_index=event.output_index,
                    sequence_number=event.sequence_number,
                    type="response.function_call_arguments.delta",
                    snapshot=output.arguments,
                )
            )

        elif event.type == "response.completed":
            response = self._completed_response
            assert response is not None

            events.append(
                build(
                    ResponseCompletedEvent,
                    sequence_number=event.sequence_number,
                    type="response.completed",
                    response=response,
                )
            )
        elif (
            event.type == "response.created"
            or event.type == "response.queued"
            or event.type == "response.in_progress"
            or event.type == "response.failed"
            or event.type == "response.incomplete"
        ):
            if getattr(event.response, "output", None) is None:
                event = model_copy(event, deep=True)
                event.response.output = (
                    [
                        cast(
                            ResponseOutputItem,
                            model_copy(
                                self._completed_output[index]
                                if index in self._completed_output
                                else self._output_items[index],
                                deep=True,
                            ),
                        )
                        for index in sorted(self._output_items.keys() | self._completed_output.keys())
                    ]
                    if event.type == "response.failed" or event.type == "response.incomplete"
                    else []
                )
            events.append(event)
        else:
            events.append(event)

        return events

    def accumulate_event(self, event: RawResponseStreamEvent) -> ParsedResponseSnapshot:
        snapshot = self.__current_snapshot
        if snapshot is None:
            return self._create_initial_response(event)

        if (
            event.type == "response.created"
            or event.type == "response.queued"
            or event.type == "response.in_progress"
            or event.type == "response.completed"
            or event.type == "response.failed"
            or event.type == "response.incomplete"
        ) and getattr(event.response, "id", None) != getattr(snapshot, "id", None):
            raise RuntimeError("Lifecycle response identity changed.")

        if event.type == "response.created" or event.type == "response.queued" or event.type == "response.in_progress":
            replacements: dict[tuple[str, str | None, str | None], ResponseOutputItem] = {}
            lifecycle_output = cast("list[ResponseOutputItem] | None", getattr(event.response, "output", None))
            for replacement_item in lifecycle_output or []:
                identity = _output_identity(replacement_item)
                if identity in replacements:
                    raise RuntimeError("Response snapshot has conflicting output identities.")
                replacements[identity] = replacement_item
            for updated_identity, replacement in replacements.items():
                index = self._completed_positions.get(updated_identity)
                if index is not None:
                    if not _compatible_output_id(self._completed_output[index], replacement):
                        raise RuntimeError("Response snapshot has conflicting output identities.")
                    self._completed_output[index] = model_copy(replacement, deep=True)
        elif event.type == "response.output_item.added":
            if getattr(event, "item", None) is None:
                return snapshot
            if event.output_index in self._output_items:
                raise RuntimeError(f"Duplicate response output index {event.output_index}.")

            if event.item.type == "function_call":
                snapshot.output.append(
                    construct_type_unchecked(
                        type_=cast(Any, ParsedResponseFunctionToolCall), value=event.item.to_dict()
                    )
                )
            elif event.item.type == "message":
                snapshot.output.append(
                    construct_type_unchecked(type_=cast(Any, ParsedResponseOutputMessage), value=event.item.to_dict())
                )
            else:
                snapshot.output.append(event.item)
            self._output_items[event.output_index] = snapshot.output[-1]
        elif event.type == "response.content_part.added":
            output = self._get_output_item(event.output_index)
            if output.type == "message":
                output.content.append(
                    construct_type_unchecked(type_=cast(Any, ParsedContent), value=event.part.to_dict())
                )
        elif event.type == "response.output_text.delta":
            output = self._get_output_item(event.output_index)
            if output.type == "message":
                content = output.content[event.content_index]
                assert content.type == "output_text"
                content.text += event.delta
        elif event.type == "response.function_call_arguments.delta":
            output = self._get_output_item(event.output_index)
            if output.type == "function_call":
                output.arguments += event.delta
        elif event.type == "response.output_item.done":
            added = self._output_items.get(event.output_index)
            if added is not None and (
                _output_identity(added) != _output_identity(event.item) or not _compatible_output_id(added, event.item)
            ):
                raise RuntimeError("Completed output item identity changed.")
            identity = _output_identity(event.item)
            position = self._completed_positions.get(identity)
            if position is not None and position != event.output_index:
                raise RuntimeError("Response snapshot has conflicting output identities.")
            previous = self._completed_output.get(event.output_index)
            if previous is not None:
                del self._completed_positions[_output_identity(previous)]
            self._completed_output[event.output_index] = event.item
            self._completed_positions[identity] = event.output_index
        elif event.type == "response.completed":
            response = event.response
            final_output = cast("list[ResponseOutputItem] | None", getattr(response, "output", None))
            final_items = {_output_identity(item): item for item in (final_output or [])}
            for completed_item in self._completed_output.values():
                final_completed_item = final_items.get(_output_identity(completed_item))
                if final_completed_item is not None and not _compatible_output_id(completed_item, final_completed_item):
                    raise RuntimeError("Completed response output identity changed.")
            for index, item in self._output_items.items():
                final_item = final_items.get(_output_identity(item))
                if index not in self._completed_output and (
                    final_item is None or not _compatible_output_id(item, final_item)
                ):
                    raise RuntimeError("Cannot complete response with unfinished output items.")
            if getattr(response, "output", None) is None:
                # Recover finalized items; deltas can omit final status, annotations, or refusals.
                response = model_copy(response)
                response.output = [self._completed_output[index] for index in sorted(self._completed_output)]
            self._completed_response = parse_response(
                text_format=self._text_format,
                response=response,
                input_tools=self._input_tools,
            )

        return snapshot

    def _get_output_item(self, output_index: int) -> ParsedResponseOutputItem[object]:
        try:
            return self._output_items[output_index]
        except KeyError:
            raise RuntimeError(
                f"Received a content event for output index {output_index} before receiving its output item"
            ) from None

    def _create_initial_response(self, event: RawResponseStreamEvent) -> ParsedResponseSnapshot:
        if event.type != "response.created":
            raise RuntimeError(f"Expected to have received `response.created` before `{event.type}`")

        snapshot = construct_type_unchecked(type_=ParsedResponseSnapshot, value=event.response.to_dict())
        # Stream indexes can have gaps when a provider emits an empty added event.
        if getattr(snapshot, "output", None) is None:
            snapshot.output = []
        self._output_items = dict(enumerate(snapshot.output))
        return snapshot
